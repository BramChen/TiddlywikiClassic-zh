config.commands.references.handler = function(event,src,title)
{
	var popup = Popup.create(src);
	if(popup)
		{
		var references = store.getReferringTiddlers(title);
		var c = false;
		var lingo = config.views.wikified.tag;
		if(references.length > 0){
			var openAll = createTiddlyButton(createTiddlyElement(popup,"li"),lingo.openAllText,lingo.openAllTooltip,onClickReferenceOpenAll);
			openAll.setAttribute("title",title);
			createTiddlyElement(createTiddlyElement(popup,"li",null,"listBreak"),"div");
		}
		for(var r=0; r<references.length; r++)
			if(references[r].title != title && !references[r].isTagged("excludeLists"))
				{
				createTiddlyLink(createTiddlyElement(popup,"li"),references[r].title,true);
				c = true;
				}
		if(!c)
			createTiddlyText(createTiddlyElement(popup,"li",null,"disabled"),this.popupNone);
		}
	Popup.show(popup,false);
	event.cancelBubble = true;
	if (event.stopPropagation) event.stopPropagation();
	return false;
}
function onClickReferenceOpenAll(e)
{
	if (!e) var e = window.event;
	var title = this.getAttribute("title");
	var references = store.getReferringTiddlers(title);
	var titles = [];
	for(var t=0; t<references.length; t++)
		titles.push(references[t].title);
	story.displayTiddlers(this,titles);
	return(false);
}