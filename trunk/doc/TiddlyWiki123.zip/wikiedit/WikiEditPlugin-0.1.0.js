/***
!Metadata:
|''Name:''|WikiEditPlugin|
|''Description:''| |
|''Version:''|0.1.0|
|''Date:''|Nov 13, 2006|
|''Source:''|http://sourceforge.net/project/showfiles.php?group_id=150646|
|''Author:''|BramChen (bram.chen (at) gmail (dot) com)|
|''License:''|[[Creative Commons Attribution-ShareAlike 2.5 License]]|
|''~CoreVersion:''|2.1.0|
|''Browser:''|Firefox 1.5+; InternetExplorer 6.0|

!Required:
* TiddlyWiki 2.1.0+
* WikiEdit
!Reference:
!Installation: 
	# Add below statement to MarkupPostHead
<script type="text/javascript" src="wikiedit/WikiEditPlugin.js"></script>

	# Add below statements to MarkupPreHead
{{{
<!-- wikiedit -->
<link rel="stylesheet" type="text/css" href="wikiedit/wikiedit.css" />
<script type="text/javascript" src="wikiedit/protoedit.js"></script>
<script type="text/javascript" src="wikiedit/twedit.js"></script>

}}}	
	# Save changes and reload page.

!Uninstall:
	* Open TW document in your edtior, and remove all lines added from installation step.

!Note:
	* for IE user, please change to the directory of wikiedit and execute "copy protoedit.js+twedit.js wikiedit.js" in command shell, then install the new wikiedit.js, Add below statements to MarkupPreHead
{{{
<!-- wikiedit -->
<link rel="stylesheet" type="text/css" href="wikiedit/wikiedit.css" />
	<script type="text/javascript" src="wikiedit/wikiedit.js"></script>
}}}	
	* You can also install all of these external scripts as normal TW plugins.

!Revision history:
	* Nov 13 2006
		** Initial release
! Codes
***/
//{{{
version.extensions.HTMLAreaPlugin = {major: 0, minor: 1, revision: 0,
	date: new Date("Nov 13, 2006"),
	name: "WikiEditPlugin",
	type: "Plugin",
	author: "BramChen",
	source: "http://sourceforge.net/project/showfiles.php?group_id=150646"
};
if (!config.commands.editTiddler.handler_WE)
	config.commands.editTiddler.handler_WE = config.commands.editTiddler.handler;
config.commands.editTiddler.handler = function(event,src,title)
{
	if(!event) var event = window.event;
	config.commands.editTiddler.handler_WE(event,src,title);

	var tiddler= document.getElementById("tiddler"+title);
	var weBody = tiddler.getElementsByTagName("textarea")[0];
	weBody.setAttribute("id","we_"+title);
	var wE = new WikiEdit();
	wE.init(weBody.id,'WikiEdit','edname','./wikiedit/images/');
	return false;
}
//}}}